 console.log("hello to this world");
 
 document.addEventListener("DOMContentLoaded", () => {
    let screen = document.getElementById('screen');
    let btns = document.getElementsByClassName("btn");
    let clear = document.querySelector('.btn-clear');
    let equal  = document.getElementById('equal-btn');



    console.log(btns.length)

    for(btn of btns) {

        btn.addEventListener("click", (e) => {
            let value = e.target.dataset.num;
            screen.value = screen.value + value;
        })
    }


    

    equal.addEventListener('click', function(e){
        let v  = screen.value;
        if(v == '') {
            screen.value = ''
        } else {
            let answer = eval(v);
            screen.value = answer;
        }

    })
   

     clear.addEventListener('click',function(e){
        screen.value = "";
     })

 })

  




